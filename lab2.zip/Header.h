#include <string>
#include<iostream>
using namespace std;
class BMI
{
private:
	float tall, mass, bmi;
public:
	float calbmi(float tall, float mass);
	string category(float bmi);
};
