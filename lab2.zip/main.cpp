#include<iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Header.h"

using namespace std;

int main()
{

	class BMI Header;

	float tall, mass;
	ifstream inFile("file.in.txt", ios::in);

	if (!inFile) {
		cout << "Failed opening" <<endl;
		
		exit(1);
	}
	ofstream outFile("file.out.txt", ios::out);
	while (inFile >> tall >> mass)
	{
		if (tall == 0)
		{
			exit(2);
		}

		outFile << Header.calbmi(tall, mass)<< Header.category(Header.calbmi(tall, mass))<<endl;
		
		
	}



	cin.get();
	return 0;
}